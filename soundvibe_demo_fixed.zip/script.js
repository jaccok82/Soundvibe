
function generatePlaylist() {
    const mood = document.getElementById('moodInput').value;
    const result = document.getElementById('result');
    if (mood.trim() === "") {
        result.innerHTML = "<p>Vul eerst je stemming in.</p>";
        return;
    }
    result.innerHTML = `<p>Afspeellijst gegenereerd voor stemming: <strong>${mood}</strong></p>`;
}
